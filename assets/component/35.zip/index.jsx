'use strict';

import React, { Component } from 'react';
import title from './title.jsx'
import './style.css';

class Page extends Component {
  render() {
    return (
      <div class="dsda">
        <div class="block_1">
          <span class="qt_text">请填写文本1212</span>
        </div>
        <div class="block_2">
          <div class="block_3">
          </div>
          <title></title>
          <title></title>
        </div>
      </div>
    );
  }
}
export default Page;
